let teks = "Merah Putih"

// Task 1 mengubah variable teks menjadi uppercase
let task1 = teks.toUpperCase()

// Task 2 mengubah variable teks menjadi lowercase
let task2 = teks.toLowerCase()

// Task 3 mengubah “Putih” menjadi “Muda” dalam variable teks
let task3 = teks.replace("Putih", "Muda")

// Task 4 mengukur Panjang (length) dari variable teks
let task4 = teks.length

alert(task1)
alert(task2)
alert(task3)
alert(task4)